// Plan (pseudocode - detailed):
// 1. Provide a minimal set of types in the `BasicWebServer.Server` namespace so `StartUp.cs`'s using resolves.
// 2. Define `IRoutingTable` with `MapGet` and `MapPost` signatures that return the table for fluent chaining.
// 3. Define `Request` with a `Form` dictionary so `StartUp.AddFormDataAction` can iterate key/value pairs.
// 4. Define `Response` exposing a `StringBuilder Body` with `Clear`/`Append` available.
// 5. Provide concrete response types used in StartUp:
//    - `TextResponse` (accepts content and optional action delegate)
//    - `HtmlResponse` (inherits `TextResponse`)
//    - `RedirectResponse` (holds Location)
//    - `BadRequestResponse`, `UnauthorizedResponse`, `NotFoundResponse` (simple defaults)
// 6. Keep implementations minimal and non-intrusive so they satisfy compilation without changing application logic.
// 7. Use simple, public types and members matching the usage in `StartUp.cs` (constructors, method signatures).
//
// Note: This shim is intentionally minimal and meant to resolve the missing namespace / type errors.
// Replace or remove it once the real server implementation is available.

using System;
using System.Collections.Generic;
using System.Text;

namespace BasicWebServer.Server
{
  
    public interface IRoutingTable
    {
        IRoutingTable MapGet(string path, Response response);
        IRoutingTable MapPost(string path, Response response);
    }

    public class Request
    {
        public IDictionary<string, string> Form { get; } = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        public Request()
        {
        }
    }

    public class Response
    {
        public StringBuilder Body { get; } = new StringBuilder();

        public Response()
        {
        }

        public virtual void SetBody(string content)
        {
            Body.Clear();
            Body.Append(content);
        }
    }

    public class TextResponse : Response
    {
        public string Content { get; }
        public Action<Request, Response>? Action { get; }

        public TextResponse(string content, Action<Request, Response>? action = null)
        {
            Content = content ?? string.Empty;
            Action = action;
            Body.Append(Content);
        }
    }

    public class HtmlResponse : TextResponse
    {
        public HtmlResponse(string content)
            : base(content)
        {
        }
    }

  
    public class RedirectResponse : Response
    {
        public string Location { get; }

        public RedirectResponse(string location)
        {
            Location = location ?? string.Empty;
            Body.Append($"Redirect: {Location}");
        }
    }

    public class BadRequestResponse : Response
    {
        public BadRequestResponse()
        {
            Body.Append("400 Bad Request");
        }
    }

    public class UnauthorizedResponse : Response
    {
        public UnauthorizedResponse()
        {
            Body.Append("401 Unauthorized");
        }
    }

    public class NotFoundResponse : Response
    {
        public NotFoundResponse()
        {
            Body.Append("404 Not Found");
        }
    }
}