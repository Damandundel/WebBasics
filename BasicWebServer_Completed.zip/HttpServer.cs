
using System;

namespace BasicWebServer.Server
{
    public sealed class HttpServer
    {
        private readonly dynamic? _configure;
        private bool _running;

        public HttpServer()
        {
            _configure = null;
        }

        public HttpServer(dynamic configure)
        {
            _configure = configure;
        }

        public void Start()
        {
            if (_running)
            {
                Console.WriteLine("HttpServer is already running.");
                return;
            }

            Console.WriteLine("Starting HttpServer...");

           
            if (_configure is not null)
            {
                try
                {
           
                    _configure();
                }
                catch (Microsoft.CSharp.RuntimeBinder.RuntimeBinderException)
                {
                    
                    try
                    {
                        _configure(this);
                    }
                    catch
                    {
                        
                    }
                }
                catch
                {
      
                }
            }

            _running = true;
            Console.WriteLine("HttpServer started.");
        }

        public void Stop()
        {
            if (!_running)
            {
                Console.WriteLine("HttpServer is not running.");
                return;
            }

            Console.WriteLine("Stopping HttpServer...");
            _running = false;
            Console.WriteLine("HttpServer stopped.");
        }
    }
}